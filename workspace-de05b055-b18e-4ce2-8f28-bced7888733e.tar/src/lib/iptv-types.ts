// IPTV application shared types

export interface ServerConfig {
  url: string
  username: string
  password: string
}

export interface Channel {
  id: string
  name: string
  url: string
  category: string
  logo?: string
  favorite?: boolean
  createdAt: number
}

export interface PairedDevice {
  id: string
  name: string
  type: 'wifi' | 'bluetooth'
  address: string
  signal: number // 0-100
  status: 'connected' | 'disconnected' | 'pairing'
  pairedAt: number
}

export type AppView =
  | 'login'
  | 'channels'
  | 'player'
  | 'pairing'
  | 'settings'

export interface PlaybackState {
  channelId: string | null
  isPlaying: boolean
  isMuted: boolean
  volume: number // 0-100
  isFullscreen: boolean
  quality: 'auto' | '1080p' | '720p' | '480p' | '360p'
}
