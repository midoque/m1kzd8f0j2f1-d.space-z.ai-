'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type {
  AppView,
  Channel,
  PairedDevice,
  PlaybackState,
  ServerConfig,
} from '@/lib/iptv-types'

// Default demo channels — use publicly available test streams so the
// playback screen is functional out of the box without real credentials.
const defaultChannels: Channel[] = [
  {
    id: 'ch-1',
    name: 'Big Buck Bunny',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    category: 'Demo',
    favorite: true,
    createdAt: Date.now(),
  },
  {
    id: 'ch-2',
    name: 'Tears of Steel',
    url: 'https://test-streams.mux.dev/tos_ismc/main.m3u8',
    category: 'Demo',
    favorite: false,
    createdAt: Date.now(),
  },
  {
    id: 'ch-3',
    name: 'Sintel Trailer',
    url: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
    category: 'Demo',
    favorite: false,
    createdAt: Date.now(),
  },
  {
    id: 'ch-4',
    name: 'Apple Basic Stream',
    url: 'https://devstreaming-cdn.apple.com/videos/streaming/examples/img_b2b_vip/index.m3u8',
    category: 'Test',
    favorite: false,
    createdAt: Date.now(),
  },
]

const defaultPairedDevices: PairedDevice[] = [
  {
    id: 'dev-1',
    name: 'Living Room TV',
    type: 'wifi',
    address: '192.168.1.42',
    signal: 88,
    status: 'connected',
    pairedAt: Date.now() - 86400000,
  },
  {
    id: 'dev-2',
    name: 'Bluetooth Headset',
    type: 'bluetooth',
    address: 'A4:C3:F0:85:AC:2D',
    signal: 64,
    status: 'disconnected',
    pairedAt: Date.now() - 172800000,
  },
  {
    id: 'dev-3',
    name: 'Kitchen Speaker',
    type: 'bluetooth',
    address: 'F8:E9:03:21:7B:91',
    signal: 72,
    status: 'disconnected',
    pairedAt: Date.now() - 259200000,
  },
  {
    id: 'dev-4',
    name: 'Bedroom Chromecast',
    type: 'wifi',
    address: '192.168.1.55',
    signal: 54,
    status: 'disconnected',
    pairedAt: Date.now() - 432000000,
  },
]

interface IPTVState {
  // Auth / server config
  server: ServerConfig | null
  isAuthed: boolean

  // Navigation
  view: AppView

  // Data
  channels: Channel[]
  pairedDevices: PairedDevice[]

  // Playback
  playback: PlaybackState

  // Settings
  theme: 'dark' | 'light'
  autoplay: boolean
  preferredQuality: PlaybackState['quality']

  // Actions
  setServer: (server: ServerConfig) => void
  logout: () => void
  setView: (view: AppView) => void

  addChannel: (channel: Omit<Channel, 'id' | 'createdAt'>) => void
  removeChannel: (id: string) => void
  toggleFavorite: (id: string) => void
  updateChannel: (id: string, patch: Partial<Channel>) => void

  playChannel: (id: string) => void
  stopPlayback: () => void
  setPlayback: (patch: Partial<PlaybackState>) => void

  pairDevice: (device: Omit<PairedDevice, 'id' | 'pairedAt'>) => void
  unpairDevice: (id: string) => void
  setDeviceStatus: (id: string, status: PairedDevice['status']) => void

  setTheme: (theme: 'dark' | 'light') => void
  setAutoplay: (autoplay: boolean) => void
  setPreferredQuality: (q: PlaybackState['quality']) => void
}

export const useIPTVStore = create<IPTVState>()(
  persist(
    (set) => ({
      server: null,
      isAuthed: false,
      view: 'login',
      channels: defaultChannels,
      pairedDevices: defaultPairedDevices,
      playback: {
        channelId: null,
        isPlaying: false,
        isMuted: false,
        volume: 80,
        isFullscreen: false,
        quality: 'auto',
      },
      theme: 'dark',
      autoplay: true,
      preferredQuality: 'auto',

      setServer: (server) =>
        set({ server, isAuthed: true, view: 'channels' }),

      logout: () =>
        set({ server: null, isAuthed: false, view: 'login' }),

      setView: (view) => set({ view }),

      addChannel: (channel) =>
        set((s) => ({
          channels: [
            { ...channel, id: `ch-${Date.now()}`, createdAt: Date.now() },
            ...s.channels,
          ],
        })),

      removeChannel: (id) =>
        set((s) => ({
          channels: s.channels.filter((c) => c.id !== id),
          playback:
            s.playback.channelId === id
              ? { ...s.playback, channelId: null }
              : s.playback,
        })),

      toggleFavorite: (id) =>
        set((s) => ({
          channels: s.channels.map((c) =>
            c.id === id ? { ...c, favorite: !c.favorite } : c,
          ),
        })),

      updateChannel: (id, patch) =>
        set((s) => ({
          channels: s.channels.map((c) =>
            c.id === id ? { ...c, ...patch } : c,
          ),
        })),

      playChannel: (id) =>
        set((s) => ({
          view: 'player',
          playback: {
            ...s.playback,
            channelId: id,
            isPlaying: true,
          },
        })),

      stopPlayback: () =>
        set((s) => ({
          playback: { ...s.playback, channelId: null, isPlaying: false },
        })),

      setPlayback: (patch) =>
        set((s) => ({ playback: { ...s.playback, ...patch } })),

      pairDevice: (device) =>
        set((s) => ({
          pairedDevices: [
            {
              ...device,
              id: `dev-${Date.now()}`,
              pairedAt: Date.now(),
            },
            ...s.pairedDevices,
          ],
        })),

      unpairDevice: (id) =>
        set((s) => ({
          pairedDevices: s.pairedDevices.filter((d) => d.id !== id),
        })),

      setDeviceStatus: (id, status) =>
        set((s) => ({
          pairedDevices: s.pairedDevices.map((d) =>
            d.id === id ? { ...d, status } : d,
          ),
        })),

      setTheme: (theme) => set({ theme }),
      setAutoplay: (autoplay) => set({ autoplay }),
      setPreferredQuality: (q) =>
        set({
          preferredQuality: q,
          playback: { ...useIPTVStore.getState().playback, quality: q },
        }),
    }),
    {
      name: 'iptv-store-v1',
      // Persist only stable data, not transient playback state like isPlaying.
      partialize: (state) => ({
        server: state.server,
        isAuthed: state.isAuthed,
        channels: state.channels,
        pairedDevices: state.pairedDevices,
        theme: state.theme,
        autoplay: state.autoplay,
        preferredQuality: state.preferredQuality,
      }),
    },
  ),
)
