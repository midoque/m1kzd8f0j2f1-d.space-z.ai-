'use client'

import { useEffect, useSyncExternalStore } from 'react'
import { useIPTVStore } from '@/lib/iptv-store'
import AppShell from '@/components/iptv/AppShell'
import LoginView from '@/components/iptv/LoginView'
import ChannelListView from '@/components/iptv/ChannelListView'
import PlayerView from '@/components/iptv/PlayerView'
import PairingView from '@/components/iptv/PairingView'
import SettingsView from '@/components/iptv/SettingsView'

// Subscribe to zustand-persist hydration. On the server this returns false;
// on the client it returns true once persisted state has been rehydrated.
function useStoreHydrated() {
  return useSyncExternalStore(
    (cb) => {
      const unsubFinish = useIPTVStore.persist.onFinishHydration(cb)
      const unsub1 = useIPTVStore.subscribe(cb)
      return () => {
        unsubFinish()
        unsub1()
      }
    },
    () => useIPTVStore.persist.hasHydrated(),
    () => false, // server snapshot — always not yet hydrated
  )
}

export default function Home() {
  const isAuthed = useIPTVStore((s) => s.isAuthed)
  const view = useIPTVStore((s) => s.view)
  const theme = useIPTVStore((s) => s.theme)
  const setView = useIPTVStore((s) => s.setView)
  const playback = useIPTVStore((s) => s.playback)
  const channels = useIPTVStore((s) => s.channels)
  const hydrated = useStoreHydrated()

  // Apply theme class on mount and whenever it changes.
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.classList.toggle('dark', theme === 'dark')
    }
  }, [theme])

  // If the user is on the player view but no channel is selected, bounce back
  // to the channel list so the player view always shows meaningful content.
  useEffect(() => {
    if (isAuthed && view === 'player' && !playback.channelId) {
      if (channels.length > 0) {
        // Auto-select the first channel rather than showing the empty state.
        setView('channels')
      }
    }
  }, [isAuthed, view, playback.channelId, channels.length, setView])

  if (!hydrated) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-muted border-t-primary animate-spin" />
      </div>
    )
  }

  if (!isAuthed) {
    return <LoginView />
  }

  return (
    <AppShell>
      {view === 'channels' && <ChannelListView />}
      {view === 'player' && <PlayerView />}
      {view === 'pairing' && <PairingView />}
      {view === 'settings' && <SettingsView />}
    </AppShell>
  )
}
