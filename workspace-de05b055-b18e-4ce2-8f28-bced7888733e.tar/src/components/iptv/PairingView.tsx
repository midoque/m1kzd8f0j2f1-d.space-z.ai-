'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Wifi,
  Bluetooth,
  Search,
  Loader2,
  Check,
  X,
  Plus,
  RefreshCw,
  Signal,
  Link2,
  Unlink,
  Cast,
  Smartphone,
  Tv2,
  Speaker,
  Headphones,
  Laptop,
} from 'lucide-react'
import { useIPTVStore } from '@/lib/iptv-store'
import type { PairedDevice } from '@/lib/iptv-types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { toast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'

// Mocked discovery list — purely for demo since the browser cannot truly
// scan Wi-Fi networks. Replace with Web Bluetooth / remote APIs in production.
const discoverable: Omit<PairedDevice, 'id' | 'pairedAt' | 'status'>[] = [
  { name: 'Samsung Smart TV', type: 'wifi', address: '192.168.1.51', signal: 92 },
  { name: 'LG Soundbar', type: 'bluetooth', address: '11:22:33:44:55:66', signal: 70 },
  { name: 'Sonos Beam', type: 'wifi', address: '192.168.1.66', signal: 78 },
  { name: 'AirPods Pro', type: 'bluetooth', address: 'AA:BB:CC:DD:EE:FF', signal: 88 },
  { name: 'Office Monitor', type: 'wifi', address: '192.168.1.78', signal: 60 },
  { name: 'JBL Flip 6', type: 'bluetooth', address: '99:88:77:66:55:44', signal: 54 },
]

function deviceIcon(name: string) {
  const n = name.toLowerCase()
  if (n.includes('tv') || n.includes('chromecast')) return <Tv2 className="h-4 w-4" />
  if (n.includes('airpod') || n.includes('headphone') || n.includes('headset')) return <Headphones className="h-4 w-4" />
  if (n.includes('speaker') || n.includes('soundbar') || n.includes('sonos') || n.includes('jbl')) return <Speaker className="h-4 w-4" />
  if (n.includes('phone')) return <Smartphone className="h-4 w-4" />
  if (n.includes('monitor') || n.includes('laptop')) return <Laptop className="h-4 w-4" />
  return <Cast className="h-4 w-4" />
}

export default function PairingView() {
  const pairedDevices = useIPTVStore((s) => s.pairedDevices)
  const pairDevice = useIPTVStore((s) => s.pairDevice)
  const unpairDevice = useIPTVStore((s) => s.unpairDevice)
  const setDeviceStatus = useIPTVStore((s) => s.setDeviceStatus)

  const [scanning, setScanning] = useState(false)
  const [discovered, setDiscovered] = useState<typeof discoverable>([])

  const wifiDevices = useMemo(
    () => pairedDevices.filter((d) => d.type === 'wifi'),
    [pairedDevices],
  )
  const btDevices = useMemo(
    () => pairedDevices.filter((d) => d.type === 'bluetooth'),
    [pairedDevices],
  )

  async function handleScan() {
    setScanning(true)
    setDiscovered([])
    // Simulate progressive discovery.
    for (let i = 0; i < discoverable.length; i++) {
      await new Promise((r) => setTimeout(r, 350))
      setDiscovered((prev) => [...prev, discoverable[i]])
    }
    setScanning(false)
    toast({
      title: 'Scan complete',
      description: `${discoverable.length} devices found nearby.`,
    })
  }

  async function handlePair(dev: Omit<PairedDevice, 'id' | 'pairedAt' | 'status'>) {
    const tempId = `pairing-${Date.now()}`
    pairDevice({ ...dev, status: 'pairing' })
    toast({
      title: 'Pairing...',
      description: `Establishing connection with ${dev.name}`,
    })
    await new Promise((r) => setTimeout(r, 1200))
    setDeviceStatus(tempId, 'connected')
    toast({
      title: 'Paired successfully',
      description: `${dev.name} is ready to receive playback.`,
    })
  }

  return (
    <div className="space-y-6 p-4 sm:p-6 lg:p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25 }}
        className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"
      >
        <div>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
            Device pairing
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Connect over Wi-Fi or Bluetooth to cast streams to nearby devices.
          </p>
        </div>
        <Button onClick={handleScan} disabled={scanning}>
          {scanning ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Scanning...
            </>
          ) : (
            <>
              <Search className="h-4 w-4" />
              Scan for devices
            </>
          )}
        </Button>
      </motion.div>

      <Tabs defaultValue="wifi">
        <TabsList className="grid w-full max-w-sm grid-cols-2">
          <TabsTrigger value="wifi" className="gap-1.5">
            <Wifi className="h-4 w-4" />
            Wi-Fi
          </TabsTrigger>
          <TabsTrigger value="bluetooth" className="gap-1.5">
            <Bluetooth className="h-4 w-4" />
            Bluetooth
          </TabsTrigger>
        </TabsList>

        {/* Wi-Fi tab */}
        <TabsContent value="wifi" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Wifi className="h-4 w-4 text-chart-2" />
                Wi-Fi network
              </CardTitle>
              <CardDescription>
                Devices on your local network can be paired for low-latency casting.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4 flex items-center gap-2 rounded-lg border border-chart-2/30 bg-chart-2/5 px-3 py-2">
                <Signal className="h-4 w-4 text-chart-2" />
                <span className="text-sm font-medium">StreamVerse_5G</span>
                <Badge variant="secondary" className="ml-auto bg-chart-2/10 text-chart-2">
                  Connected
                </Badge>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Paired Wi-Fi devices ({wifiDevices.length})</span>
                  <ManualPairDialog type="wifi" />
                </div>

                {wifiDevices.length === 0 ? (
                  <div className="rounded-lg border border-dashed p-6 text-center">
                    <p className="text-sm font-medium">No paired Wi-Fi devices</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Run a scan or pair a device manually.
                    </p>
                  </div>
                ) : (
                  wifiDevices.map((d) => (
                    <DeviceRow
                      key={d.id}
                      device={d}
                      onToggle={() =>
                        setDeviceStatus(
                          d.id,
                          d.status === 'connected' ? 'disconnected' : 'connected',
                        )
                      }
                      onUnpair={() => {
                        unpairDevice(d.id)
                        toast({ title: 'Device unpaired', description: d.name })
                      }}
                    />
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Bluetooth tab */}
        <TabsContent value="bluetooth" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Bluetooth className="h-4 w-4 text-chart-5" />
                Bluetooth
              </CardTitle>
              <CardDescription>
                Pair headphones, speakers, and other Bluetooth A2DP devices.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4 flex items-center gap-2 rounded-lg border border-chart-5/30 bg-chart-5/5 px-3 py-2">
                <Bluetooth className="h-4 w-4 text-chart-5" />
                <span className="text-sm font-medium">Bluetooth radio</span>
                <Badge variant="secondary" className="ml-auto bg-chart-5/10 text-chart-5">
                  On
                </Badge>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Paired Bluetooth devices ({btDevices.length})</span>
                  <ManualPairDialog type="bluetooth" />
                </div>

                {btDevices.length === 0 ? (
                  <div className="rounded-lg border border-dashed p-6 text-center">
                    <p className="text-sm font-medium">No paired Bluetooth devices</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Run a scan or pair a device manually.
                    </p>
                  </div>
                ) : (
                  btDevices.map((d) => (
                    <DeviceRow
                      key={d.id}
                      device={d}
                      onToggle={() =>
                        setDeviceStatus(
                          d.id,
                          d.status === 'connected' ? 'disconnected' : 'connected',
                        )
                      }
                      onUnpair={() => {
                        unpairDevice(d.id)
                        toast({ title: 'Device unpaired', description: d.name })
                      }}
                    />
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Discovery */}
      {(scanning || discovered.length > 0) && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2 text-base">
                  {scanning ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Search className="h-4 w-4" />
                  )}
                  Discovered devices
                </CardTitle>
                <CardDescription>
                  {scanning
                    ? 'Searching for nearby devices...'
                    : `${discovered.length} devices found`}
                </CardDescription>
              </div>
              {!scanning && discovered.length > 0 && (
                <Button variant="ghost" size="sm" onClick={handleScan}>
                  <RefreshCw className="h-4 w-4" />
                  Rescan
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {discovered.map((d, idx) => {
                const already = pairedDevices.some(
                  (p) => p.address === d.address,
                )
                return (
                  <motion.div
                    key={`${d.address}-${idx}`}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex items-center gap-3 rounded-lg border p-3"
                  >
                    <div
                      className={cn(
                        'flex h-9 w-9 items-center justify-center rounded-md',
                        d.type === 'wifi'
                          ? 'bg-chart-2/10 text-chart-2'
                          : 'bg-chart-5/10 text-chart-5',
                      )}
                    >
                      {deviceIcon(d.name)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{d.name}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {d.address}
                      </p>
                    </div>
                    <SignalBars signal={d.signal} />
                    {already ? (
                      <Badge variant="secondary" className="shrink-0">
                        <Check className="h-3 w-3" />
                        Paired
                      </Badge>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        className="shrink-0"
                        onClick={() => handlePair(d)}
                      >
                        <Link2 className="h-3.5 w-3.5" />
                        Pair
                      </Button>
                    )}
                  </motion.div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function SignalBars({ signal }: { signal: number }) {
  const bars = 4
  const active = Math.max(1, Math.round((signal / 100) * bars))
  return (
    <div className="hidden items-end gap-0.5 sm:flex" aria-label={`Signal ${signal}%`}>
      {Array.from({ length: bars }).map((_, i) => (
        <div
          key={i}
          className={cn(
            'w-1 rounded-sm',
            i < active ? 'bg-chart-2' : 'bg-muted',
          )}
          style={{ height: `${(i + 1) * 3 + 4}px` }}
        />
      ))}
    </div>
  )
}

function DeviceRow({
  device,
  onToggle,
  onUnpair,
}: {
  device: PairedDevice
  onToggle: () => void
  onUnpair: () => void
}) {
  return (
    <div className="flex items-center gap-3 rounded-lg border p-3">
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-md',
          device.type === 'wifi'
            ? 'bg-chart-2/10 text-chart-2'
            : 'bg-chart-5/10 text-chart-5',
        )}
      >
        {deviceIcon(device.name)}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <p className="truncate text-sm font-medium">{device.name}</p>
          {device.status === 'pairing' && (
            <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />
          )}
        </div>
        <p className="truncate text-xs text-muted-foreground">{device.address}</p>
        {device.status === 'connected' && (
          <div className="mt-1.5 flex items-center gap-2">
            <Progress value={device.signal} className="h-1 w-20" />
            <span className="text-[10px] text-muted-foreground">{device.signal}%</span>
          </div>
        )}
      </div>
      <Badge
        variant="secondary"
        className={cn(
          'shrink-0',
          device.status === 'connected' && 'bg-chart-2/10 text-chart-2',
          device.status === 'pairing' && 'bg-chart-1/10 text-chart-1',
          device.status === 'disconnected' && 'bg-muted text-muted-foreground',
        )}
      >
        {device.status === 'connected' && (
          <>
            <Check className="h-3 w-3" />
            Connected
          </>
        )}
        {device.status === 'pairing' && <>Pairing</>}
        {device.status === 'disconnected' && <>Offline</>}
      </Badge>
      <Button size="sm" variant="outline" onClick={onToggle}>
        {device.status === 'connected' ? (
          <>
            <Unlink className="h-3.5 w-3.5" />
            Disconnect
          </>
        ) : (
          <>
            <Link2 className="h-3.5 w-3.5" />
            Connect
          </>
        )}
      </Button>
      <Button
        size="sm"
        variant="ghost"
        onClick={onUnpair}
        aria-label="Unpair"
        className="text-muted-foreground hover:text-destructive"
      >
        <X className="h-4 w-4" />
      </Button>
    </div>
  )
}

function ManualPairDialog({ type }: { type: 'wifi' | 'bluetooth' }) {
  const pairDevice = useIPTVStore((s) => s.pairDevice)
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [address, setAddress] = useState('')
  const [submitting, setSubmitting] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!name.trim() || !address.trim()) {
      toast({
        title: 'Missing fields',
        description: 'Both name and address are required.',
        variant: 'destructive',
      })
      return
    }
    setSubmitting(true)
    await new Promise((r) => setTimeout(r, 800))
    pairDevice({
      name: name.trim(),
      address: address.trim(),
      type,
      signal: 75,
      status: 'disconnected',
    })
    setSubmitting(false)
    setOpen(false)
    setName('')
    setAddress('')
    toast({
      title: 'Device added',
      description: `${name.trim()} added to your ${type.toUpperCase()} devices.`,
    })
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm">
          <Plus className="h-3.5 w-3.5" />
          Add manually
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add {type === 'wifi' ? 'Wi-Fi' : 'Bluetooth'} device</DialogTitle>
          <DialogDescription>
            Enter the device details to add it to your paired list.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="dev-name">Device name</Label>
            <Input
              id="dev-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Living Room TV"
              autoFocus
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="dev-addr">
              {type === 'wifi' ? 'IP address' : 'MAC address'}
            </Label>
            <Input
              id="dev-addr"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder={type === 'wifi' ? '192.168.1.42' : 'AA:BB:CC:DD:EE:FF'}
            />
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Adding...
                </>
              ) : (
                'Add device'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
