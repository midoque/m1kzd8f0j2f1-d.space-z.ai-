'use client'

import { useMemo, useState, FormEvent } from 'react'
import { motion } from 'framer-motion'
import {
  Search,
  Plus,
  Star,
  Trash2,
  Play,
  Tv2,
  ListVideo,
  Loader2,
  Filter,
  Wifi,
  Bluetooth,
  Radio,
} from 'lucide-react'
import { useIPTVStore } from '@/lib/iptv-store'
import type { Channel } from '@/lib/iptv-types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { toast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'

export default function ChannelListView() {
  const channels = useIPTVStore((s) => s.channels)
  const playChannel = useIPTVStore((s) => s.playChannel)
  const removeChannel = useIPTVStore((s) => s.removeChannel)
  const toggleFavorite = useIPTVStore((s) => s.toggleFavorite)
  const pairedDevices = useIPTVStore((s) => s.pairedDevices)

  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState<'all' | 'favorites'>('all')

  const filtered = useMemo(() => {
    return channels
      .filter((c) => (filter === 'favorites' ? c.favorite : true))
      .filter((c) =>
        query
          ? c.name.toLowerCase().includes(query.toLowerCase()) ||
            c.category.toLowerCase().includes(query.toLowerCase())
          : true,
      )
  }, [channels, query, filter])

  const categories = useMemo(() => {
    const set = new Set<string>()
    channels.forEach((c) => set.add(c.category || 'Uncategorized'))
    return Array.from(set).sort()
  }, [channels])

  const connectedDevices = pairedDevices.filter((d) => d.status === 'connected')
  const connectedWifi = connectedDevices.filter((d) => d.type === 'wifi').length
  const connectedBt = connectedDevices.filter((d) => d.type === 'bluetooth').length

  function handlePlay(channel: Channel) {
    playChannel(channel.id)
    toast({
      title: 'Now playing',
      description: channel.name,
    })
  }

  return (
    <div className="space-y-6 p-4 sm:p-6 lg:p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25 }}
        className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"
      >
        <div>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
            Channels
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Browse, search and play from your channel library.
          </p>
        </div>
        <AddChannelDialog />
      </motion.div>

      {/* Status strip */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard
          label="Total channels"
          value={channels.length}
          icon={<Tv2 className="h-4 w-4" />}
          tone="primary"
        />
        <StatCard
          label="Categories"
          value={categories.length}
          icon={<ListVideo className="h-4 w-4" />}
          tone="accent"
        />
        <StatCard
          label="Wi-Fi devices"
          value={connectedWifi}
          icon={<Wifi className="h-4 w-4" />}
          tone="chart2"
        />
        <StatCard
          label="Bluetooth"
          value={connectedBt}
          icon={<Bluetooth className="h-4 w-4" />}
          tone="chart5"
        />
      </div>

      {/* Toolbar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name or category..."
            className="pl-9"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <div className="inline-flex rounded-md border border-border bg-card p-0.5">
            <button
              onClick={() => setFilter('all')}
              className={cn(
                'rounded px-3 py-1.5 text-sm font-medium transition-colors',
                filter === 'all'
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground',
              )}
            >
              All
            </button>
            <button
              onClick={() => setFilter('favorites')}
              className={cn(
                'rounded px-3 py-1.5 text-sm font-medium transition-colors',
                filter === 'favorites'
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground',
              )}
            >
              Favorites
            </button>
          </div>
        </div>
      </div>

      {/* Channel grid */}
      {filtered.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center gap-3 py-16 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
              <Radio className="h-5 w-5" />
            </div>
            <div>
              <p className="font-medium">No channels found</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Add a channel stream link to get started.
              </p>
            </div>
            <AddChannelDialog />
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((channel, idx) => (
            <motion.div
              key={channel.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2, delay: Math.min(idx * 0.03, 0.3) }}
            >
              <Card className="group relative overflow-hidden transition-shadow hover:shadow-lg">
                <div className="relative aspect-video overflow-hidden bg-muted">
                  <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-primary/10 via-chart-5/5 to-chart-1/10">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/90 text-primary-foreground shadow-lg transition-transform group-hover:scale-110">
                      <Play className="h-5 w-5 translate-x-0.5 fill-current" />
                    </div>
                  </div>
                  <div className="absolute left-2 top-2 flex items-center gap-1">
                    <Badge variant="secondary" className="bg-background/80 backdrop-blur">
                      {channel.category || 'Uncategorized'}
                    </Badge>
                  </div>
                  <button
                    onClick={() => toggleFavorite(channel.id)}
                    className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-background/80 backdrop-blur transition-colors hover:bg-background"
                    aria-label={channel.favorite ? 'Remove from favorites' : 'Add to favorites'}
                  >
                    <Star
                      className={cn(
                        'h-4 w-4 transition-colors',
                        channel.favorite
                          ? 'fill-chart-5 text-chart-5'
                          : 'text-muted-foreground',
                      )}
                    />
                  </button>
                </div>
                <CardContent className="p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <h3 className="truncate font-medium">{channel.name}</h3>
                      <p className="mt-0.5 truncate text-xs text-muted-foreground">
                        {channel.url}
                      </p>
                    </div>
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    <Button
                      size="sm"
                      className="flex-1"
                      onClick={() => handlePlay(channel)}
                    >
                      <Play className="h-3.5 w-3.5 fill-current" />
                      Play
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        removeChannel(channel.id)
                        toast({
                          title: 'Channel removed',
                          description: channel.name,
                        })
                      }}
                      aria-label="Remove channel"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}

function StatCard({
  label,
  value,
  icon,
  tone,
}: {
  label: string
  value: number
  icon: React.ReactNode
  tone: 'primary' | 'accent' | 'chart2' | 'chart5'
}) {
  const toneClass = {
    primary: 'bg-primary/10 text-primary',
    accent: 'bg-accent-foreground/5 text-foreground',
    chart2: 'bg-chart-2/10 text-chart-2',
    chart5: 'bg-chart-5/10 text-chart-5',
  }[tone]
  return (
    <Card>
      <CardContent className="flex items-center gap-3 p-4">
        <div className={cn('flex h-9 w-9 items-center justify-center rounded-lg', toneClass)}>
          {icon}
        </div>
        <div className="min-w-0">
          <p className="truncate text-xs text-muted-foreground">{label}</p>
          <p className="text-lg font-semibold">{value}</p>
        </div>
      </CardContent>
    </Card>
  )
}

function AddChannelDialog() {
  const addChannel = useIPTVStore((s) => s.addChannel)
  const channels = useIPTVStore((s) => s.channels)
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [url, setUrl] = useState('')
  const [category, setCategory] = useState('Custom')
  const [submitting, setSubmitting] = useState(false)

  const categories = useMemo(() => {
    const set = new Set<string>(channels.map((c) => c.category))
    return Array.from(set).sort()
  }, [channels])

  function reset() {
    setName('')
    setUrl('')
    setCategory('Custom')
    setSubmitting(false)
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!name.trim() || !url.trim()) {
      toast({
        title: 'Missing fields',
        description: 'Channel name and stream URL are required.',
        variant: 'destructive',
      })
      return
    }
    setSubmitting(true)
    await new Promise((r) => setTimeout(r, 600))
    addChannel({
      name: name.trim(),
      url: url.trim(),
      category: category.trim() || 'Custom',
      favorite: false,
    })
    setSubmitting(false)
    setOpen(false)
    reset()
    toast({
      title: 'Channel added',
      description: name.trim(),
    })
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) reset() }}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4" />
          Add channel
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add channel stream</DialogTitle>
          <DialogDescription>
            Paste a stream URL (HLS/m3u8, MP4, or DASH) to add it to your library.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="ch-name">Channel name</Label>
            <Input
              id="ch-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Sports HD"
              autoFocus
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ch-url">Stream URL</Label>
            <Input
              id="ch-url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://example.com/stream.m3u8"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ch-category">Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger id="ch-category">
                <SelectValue placeholder="Pick a category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
                <SelectItem value="Custom">Custom</SelectItem>
                <SelectItem value="News">News</SelectItem>
                <SelectItem value="Sports">Sports</SelectItem>
                <SelectItem value="Movies">Movies</SelectItem>
                <SelectItem value="Kids">Kids</SelectItem>
                <SelectItem value="Music">Music</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => { setOpen(false); reset() }}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save channel'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
