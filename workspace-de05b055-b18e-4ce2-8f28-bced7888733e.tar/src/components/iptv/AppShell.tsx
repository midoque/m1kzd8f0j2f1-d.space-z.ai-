'use client'

import { useEffect } from 'react'
import {
  Tv,
  ListVideo,
  Play,
  Bluetooth,
  Settings,
  LogOut,
  Wifi,
} from 'lucide-react'
import { useIPTVStore } from '@/lib/iptv-store'
import type { AppView } from '@/lib/iptv-types'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

const NAV_ITEMS: { id: AppView; label: string; icon: React.ReactNode }[] = [
  { id: 'channels', label: 'Channels', icon: <ListVideo className="h-4 w-4" /> },
  { id: 'player', label: 'Player', icon: <Play className="h-4 w-4" /> },
  { id: 'pairing', label: 'Pairing', icon: <Bluetooth className="h-4 w-4" /> },
  { id: 'settings', label: 'Settings', icon: <Settings className="h-4 w-4" /> },
]

export default function AppShell({ children }: { children: React.ReactNode }) {
  const view = useIPTVStore((s) => s.view)
  const setView = useIPTVStore((s) => s.setView)
  const server = useIPTVStore((s) => s.server)
  const logout = useIPTVStore((s) => s.logout)
  const theme = useIPTVStore((s) => s.theme)
  const setTheme = useIPTVStore((s) => s.setTheme)
  const pairedDevices = useIPTVStore((s) => s.pairedDevices)
  const playback = useIPTVStore((s) => s.playback)

  // Apply theme class to <html>
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.classList.toggle('dark', theme === 'dark')
    }
  }, [theme])

  const connectedCount = pairedDevices.filter((d) => d.status === 'connected').length
  const activeChannel = useIPTVStore((s) => s.channels.find((c) => c.id === s.playback.channelId))

  const initials = (server?.username ?? 'U').slice(0, 2).toUpperCase()

  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground lg:flex-row">
      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col border-r bg-card lg:flex">
        <div className="flex items-center gap-2 border-b px-5 py-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Tv className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm font-semibold leading-tight">StreamVerse</p>
            <p className="text-[10px] text-muted-foreground">IPTV Player</p>
          </div>
        </div>

        <nav className="flex-1 space-y-1 px-3 py-4">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={cn(
                'flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors',
                view === item.id
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground',
              )}
            >
              {item.icon}
              {item.label}
              {item.id === 'pairing' && connectedCount > 0 && (
                <Badge
                  variant="secondary"
                  className={cn(
                    'ml-auto',
                    view === item.id
                      ? 'bg-primary-foreground/20 text-primary-foreground'
                      : 'bg-chart-2/10 text-chart-2',
                  )}
                >
                  {connectedCount}
                </Badge>
              )}
              {item.id === 'player' && activeChannel && (
                <span
                  className={cn(
                    'ml-auto flex h-1.5 w-1.5',
                    playback.isPlaying ? 'animate-pulse rounded-full bg-chart-5' : 'rounded-full bg-muted-foreground',
                  )}
                />
              )}
            </button>
          ))}
        </nav>

        <div className="border-t p-3">
          <div className="flex items-center gap-3 rounded-lg p-2">
            <Avatar className="h-9 w-9">
              <AvatarFallback className="bg-primary/10 text-primary">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">
                {server?.username ?? 'guest'}
              </p>
              <p className="truncate text-[10px] text-muted-foreground">
                {server?.url ?? '—'}
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="mt-1 w-full justify-start text-muted-foreground hover:text-foreground"
            onClick={() => {
              logout()
              setTheme('dark')
            }}
          >
            <LogOut className="h-4 w-4" />
            Sign out
          </Button>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b bg-card/80 px-4 py-3 backdrop-blur lg:hidden">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <Tv className="h-4 w-4" />
          </div>
          <span className="text-sm font-semibold">StreamVerse</span>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            logout()
            setTheme('dark')
          }}
          aria-label="Sign out"
        >
          <LogOut className="h-4 w-4" />
        </Button>
      </header>

      {/* Main content */}
      <main className="flex-1 overflow-x-hidden pb-20 lg:pb-0">
        {children}
      </main>

      {/* Mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-30 flex items-stretch border-t bg-card/95 backdrop-blur lg:hidden">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id)}
            className={cn(
              'relative flex flex-1 flex-col items-center justify-center gap-1 py-2.5 text-[10px] font-medium transition-colors',
              view === item.id
                ? 'text-primary'
                : 'text-muted-foreground',
            )}
          >
            {item.icon}
            {item.label}
            {view === item.id && (
              <span className="absolute top-0 h-0.5 w-8 rounded-full bg-primary" />
            )}
            {item.id === 'pairing' && connectedCount > 0 && (
              <span className="absolute right-3 top-1.5 flex h-1.5 w-1.5 rounded-full bg-chart-5" />
            )}
          </button>
        ))}
      </nav>

      {/* Wi-Fi/Bluetooth connectivity quick status (desktop, top-right floating pill) */}
      <div className="pointer-events-none fixed right-4 top-4 z-40 hidden lg:block">
        <div className="pointer-events-auto flex items-center gap-2 rounded-full border bg-card/80 px-3 py-1.5 text-xs backdrop-blur shadow-sm">
          <span className="flex items-center gap-1">
            <Wifi className="h-3.5 w-3.5 text-chart-2" />
            <span className="font-medium">Wi-Fi</span>
          </span>
          <span className="text-muted-foreground">·</span>
          <span className="flex items-center gap-1">
            <Bluetooth className="h-3.5 w-3.5 text-chart-5" />
            <span className="font-medium">BT</span>
          </span>
          <span className="ml-1 rounded-full bg-chart-2/10 px-1.5 text-[10px] font-medium text-chart-2">
            {connectedCount} live
          </span>
        </div>
      </div>
    </div>
  )
}
