'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import Hls from 'hls.js'
import {
  ArrowLeft,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  Loader2,
  AlertTriangle,
  List,
  Star,
  Wifi,
  Bluetooth,
  Cast,
  Settings2,
  Volume1,
} from 'lucide-react'
import { useIPTVStore } from '@/lib/iptv-store'
import type { Channel } from '@/lib/iptv-types'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Card,
  CardContent,
} from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import { cn } from '@/lib/utils'
import { toast } from '@/hooks/use-toast'

export default function PlayerView() {
  const channels = useIPTVStore((s) => s.channels)
  const playback = useIPTVStore((s) => s.playback)
  const setPlayback = useIPTVStore((s) => s.setPlayback)
  const setView = useIPTVStore((s) => s.setView)
  const toggleFavorite = useIPTVStore((s) => s.toggleFavorite)
  const preferredQuality = useIPTVStore((s) => s.preferredQuality)
  const setPreferredQuality = useIPTVStore((s) => s.setPreferredQuality)
  const pairedDevices = useIPTVStore((s) => s.pairedDevices)

  const videoRef = useRef<HTMLVideoElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const hlsRef = useRef<Hls | null>(null)

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showControls, setShowControls] = useState(true)
  const [castTarget, setCastTarget] = useState<string | null>(null)

  const channel = useMemo<Channel | undefined>(
    () => channels.find((c) => c.id === playback.channelId),
    [channels, playback.channelId],
  )

  const connectedDevices = pairedDevices.filter((d) => d.status === 'connected')
  const castTargetDevice = connectedDevices.find((d) => d.id === castTarget)

  // Load the stream whenever the active channel changes.
  useEffect(() => {
    const video = videoRef.current
    if (!video || !channel) return

    setLoading(true)
    setError(null)

    // Tear down any previous HLS instance.
    if (hlsRef.current) {
      hlsRef.current.destroy()
      hlsRef.current = null
    }

    const isHls = /\.m3u8(\?|$)/i.test(channel.url) || channel.url.includes('m3u8')

    if (isHls && Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: false,
        capLevelToPlayerSize: true,
      })
      hlsRef.current = hls
      hls.loadSource(channel.url)
      hls.attachMedia(video)
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setLoading(false)
        if (useIPTVStore.getState().autoplay) {
          video.play().catch(() => {})
        }
      })
      hls.on(Hls.Events.ERROR, (_evt, data) => {
        if (data.fatal) {
          setLoading(false)
          setError(data.details || 'Unable to load stream')
        }
      })
    } else {
      // Native HLS (Safari) or direct MP4/WebM.
      video.src = channel.url
      const onLoaded = () => {
        setLoading(false)
        if (useIPTVStore.getState().autoplay) {
          video.play().catch(() => {})
        }
      }
      const onError = () => {
        setLoading(false)
        setError('Unable to load stream. Check the URL and try again.')
      }
      video.addEventListener('loadedmetadata', onLoaded, { once: true })
      video.addEventListener('error', onError, { once: true })
    }

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy()
        hlsRef.current = null
      }
    }
  }, [channel?.id])

  // Sync play/pause state with the store.
  useEffect(() => {
    const video = videoRef.current
    if (!video) return
    if (playback.isPlaying && video.paused) {
      video.play().catch(() => {})
    } else if (!playback.isPlaying && !video.paused) {
      video.pause()
    }
  }, [playback.isPlaying])

  // Sync volume/mute.
  useEffect(() => {
    const video = videoRef.current
    if (!video) return
    video.volume = playback.volume / 100
    video.muted = playback.isMuted
  }, [playback.volume, playback.isMuted])

  // Auto-hide controls after inactivity when playing.
  useEffect(() => {
    if (!playback.isPlaying) {
      setShowControls(true)
      return
    }
    let timer: ReturnType<typeof setTimeout> | undefined
    const schedule = () => {
      setShowControls(true)
      if (timer) clearTimeout(timer)
      timer = setTimeout(() => setShowControls(false), 3500)
    }
    const el = containerRef.current
    if (!el) return
    el.addEventListener('mousemove', schedule)
    el.addEventListener('touchstart', schedule)
    schedule()
    return () => {
      if (timer) clearTimeout(timer)
      el.removeEventListener('mousemove', schedule)
      el.removeEventListener('touchstart', schedule)
    }
  }, [playback.isPlaying])

  function togglePlay() {
    setPlayback({ isPlaying: !playback.isPlaying })
  }

  function toggleMute() {
    setPlayback({ isMuted: !playback.isMuted })
  }

  function toggleFullscreen() {
    const el = containerRef.current
    if (!el) return
    if (!document.fullscreenElement) {
      el.requestFullscreen?.().then(() => setPlayback({ isFullscreen: true })).catch(() => {})
    } else {
      document.exitFullscreen?.().then(() => setPlayback({ isFullscreen: false })).catch(() => {})
    }
  }

  function handleVolumeChange(e: React.ChangeEvent<HTMLInputElement>) {
    const v = Number(e.target.value)
    setPlayback({ volume: v, isMuted: v === 0 })
  }

  function handleCast(deviceId: string | null) {
    setCastTarget(deviceId)
    if (deviceId) {
      const dev = pairedDevices.find((d) => d.id === deviceId)
      toast({
        title: 'Casting started',
        description: dev ? `Streaming to ${dev.name}` : undefined,
      })
    } else {
      toast({ title: 'Casting stopped', description: 'Playback returned to this device' })
    }
  }

  if (!channel) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 p-6 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted text-muted-foreground">
          <AlertTriangle className="h-6 w-6" />
        </div>
        <div>
          <h2 className="text-lg font-semibold">No channel selected</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Pick a channel from the library to start watching.
          </p>
        </div>
        <Button onClick={() => setView('channels')}>
          <List className="h-4 w-4" />
          Browse channels
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-4 p-4 sm:p-6 lg:p-8">
      {/* Top bar */}
      <div className="flex items-center justify-between gap-3">
        <Button variant="ghost" size="sm" onClick={() => setView('channels')}>
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>
        <div className="flex items-center gap-2">
          <CastMenu
            devices={connectedDevices}
            castTarget={castTarget}
            onCast={handleCast}
          />
          <Button
            variant="outline"
            size="sm"
            onClick={() => toggleFavorite(channel.id)}
          >
            <Star
              className={cn(
                'h-4 w-4',
                channel.favorite && 'fill-chart-5 text-chart-5',
              )}
            />
            Favorite
          </Button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        {/* Player */}
        <div className="space-y-3">
          <div
            ref={containerRef}
            className={cn(
              'group relative aspect-video w-full overflow-hidden rounded-xl bg-black shadow-2xl',
              !showControls && playback.isPlaying && 'cursor-none',
            )}
          >
            <video
              ref={videoRef}
              className="h-full w-full"
              playsInline
              onClick={togglePlay}
            />

            {/* Loading overlay */}
            {loading && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/60 text-white">
                <Loader2 className="h-8 w-8 animate-spin" />
                <p className="text-sm">Loading stream...</p>
              </div>
            )}

            {/* Error overlay */}
            {error && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/80 p-6 text-center text-white">
                <AlertTriangle className="h-8 w-8 text-chart-5" />
                <p className="text-sm font-medium">Playback error</p>
                <p className="max-w-sm text-xs text-white/70">{error}</p>
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    setPlayback({ channelId: null })
                    setTimeout(() => setPlayback({ channelId: channel.id, isPlaying: true }), 50)
                  }}
                >
                  Retry
                </Button>
              </div>
            )}

            {/* Cast indicator */}
            {castTargetDevice && (
              <div className="absolute right-3 top-3 flex items-center gap-1.5 rounded-full bg-black/70 px-3 py-1.5 text-xs text-white backdrop-blur">
                <Cast className="h-3.5 w-3.5 fill-chart-5 text-chart-5" />
                Casting to {castTargetDevice.name}
              </div>
            )}

            {/* Bottom controls */}
            <div
              className={cn(
                'absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent px-4 pb-3 pt-10 transition-opacity duration-200',
                showControls ? 'opacity-100' : 'opacity-0',
              )}
            >
              <div className="flex items-center gap-3 text-white">
                <button
                  onClick={togglePlay}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 transition-colors hover:bg-white/20"
                  aria-label={playback.isPlaying ? 'Pause' : 'Play'}
                >
                  {playback.isPlaying ? (
                    <Pause className="h-4 w-4 fill-current" />
                  ) : (
                    <Play className="h-4 w-4 translate-x-0.5 fill-current" />
                  )}
                </button>
                <button
                  onClick={toggleMute}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 transition-colors hover:bg-white/20"
                  aria-label={playback.isMuted ? 'Unmute' : 'Mute'}
                >
                  {playback.isMuted || playback.volume === 0 ? (
                    <VolumeX className="h-4 w-4" />
                  ) : playback.volume < 50 ? (
                    <Volume1 className="h-4 w-4" />
                  ) : (
                    <Volume2 className="h-4 w-4" />
                  )}
                </button>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={playback.isMuted ? 0 : playback.volume}
                  onChange={handleVolumeChange}
                  aria-label="Volume"
                  className="h-1 w-24 cursor-pointer appearance-none rounded-full bg-white/20 accent-white sm:w-32"
                />
                <div className="ml-auto flex items-center gap-1">
                  <Badge variant="secondary" className="bg-white/10 text-white backdrop-blur">
                    LIVE
                  </Badge>
                </div>
                <Select
                  value={preferredQuality}
                  onValueChange={(v) =>
                    setPreferredQuality(v as typeof preferredQuality)
                  }
                >
                  <SelectTrigger className="h-8 w-[88px] border-white/20 bg-white/10 text-xs text-white backdrop-blur">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Auto</SelectItem>
                    <SelectItem value="1080p">1080p</SelectItem>
                    <SelectItem value="720p">720p</SelectItem>
                    <SelectItem value="480p">480p</SelectItem>
                    <SelectItem value="360p">360p</SelectItem>
                  </SelectContent>
                </Select>
                <button
                  onClick={toggleFullscreen}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 transition-colors hover:bg-white/20"
                  aria-label={playback.isFullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}
                >
                  {playback.isFullscreen ? (
                    <Minimize className="h-4 w-4" />
                  ) : (
                    <Maximize className="h-4 w-4" />
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Channel header */}
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <h1 className="truncate text-xl font-semibold tracking-tight sm:text-2xl">
                {channel.name}
              </h1>
              <p className="mt-1 truncate text-xs text-muted-foreground sm:text-sm">
                {channel.url}
              </p>
            </div>
            <Badge variant="secondary" className="shrink-0">
              {channel.category || 'Uncategorized'}
            </Badge>
          </div>
        </div>

        {/* Playlist sidebar */}
        <Card>
          <CardContent className="p-0">
            <div className="flex items-center justify-between border-b px-4 py-3">
              <div className="flex items-center gap-2">
                <List className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Up next</span>
              </div>
              <span className="text-xs text-muted-foreground">
                {channels.length} channels
              </span>
            </div>
            <div className="max-h-[480px] overflow-y-auto">
              {channels.map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    setPlayback({ channelId: c.id, isPlaying: true })
                    toast({ title: 'Now playing', description: c.name })
                  }}
                  className={cn(
                    'flex w-full items-center gap-3 border-b border-border/40 px-4 py-2.5 text-left transition-colors hover:bg-muted/50',
                    c.id === channel.id && 'bg-primary/5',
                  )}
                >
                  <div
                    className={cn(
                      'flex h-8 w-8 shrink-0 items-center justify-center rounded-md',
                      c.id === channel.id
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-muted-foreground',
                    )}
                  >
                    {c.id === channel.id && playback.isPlaying ? (
                      <Pause className="h-3.5 w-3.5 fill-current" />
                    ) : (
                      <Play className="h-3.5 w-3.5 translate-x-0.5 fill-current" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className={cn('truncate text-sm font-medium', c.id === channel.id && 'text-primary')}>
                      {c.name}
                    </p>
                    <p className="truncate text-xs text-muted-foreground">
                      {c.category}
                    </p>
                  </div>
                  {c.favorite && (
                    <Star className="h-3.5 w-3.5 shrink-0 fill-chart-5 text-chart-5" />
                  )}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function CastMenu({
  devices,
  castTarget,
  onCast,
}: {
  devices: { id: string; name: string; type: 'wifi' | 'bluetooth'; address: string }[]
  castTarget: string | null
  onCast: (id: string | null) => void
}) {
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm">
          <Cast className="h-4 w-4" />
          Cast
        </Button>
      </SheetTrigger>
      <SheetContent className="w-full sm:max-w-sm">
        <SheetHeader>
          <SheetTitle>Cast to a device</SheetTitle>
        </SheetHeader>
        <div className="mt-4 space-y-2">
          {devices.length === 0 ? (
            <div className="rounded-lg border border-dashed p-6 text-center">
              <p className="text-sm font-medium">No connected devices</p>
              <p className="mt-1 text-xs text-muted-foreground">
                Pair a device in the Pairing tab to enable casting.
              </p>
            </div>
          ) : (
            <>
              <button
                onClick={() => onCast(null)}
                className={cn(
                  'flex w-full items-center gap-3 rounded-lg border p-3 text-left transition-colors hover:bg-muted/50',
                  castTarget === null && 'border-primary bg-primary/5',
                )}
              >
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
                  <Settings2 className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium">This device</p>
                  <p className="text-xs text-muted-foreground">Play here</p>
                </div>
              </button>
              {devices.map((d) => (
                <button
                  key={d.id}
                  onClick={() => onCast(d.id)}
                  className={cn(
                    'flex w-full items-center gap-3 rounded-lg border p-3 text-left transition-colors hover:bg-muted/50',
                    castTarget === d.id && 'border-primary bg-primary/5',
                  )}
                >
                  <div
                    className={cn(
                      'flex h-9 w-9 items-center justify-center rounded-md',
                      d.type === 'wifi'
                        ? 'bg-chart-2/10 text-chart-2'
                        : 'bg-chart-5/10 text-chart-5',
                    )}
                  >
                    {d.type === 'wifi' ? (
                      <Wifi className="h-4 w-4" />
                    ) : (
                      <Bluetooth className="h-4 w-4" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{d.name}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {d.address}
                    </p>
                  </div>
                </button>
              ))}
            </>
          )}
        </div>
      </SheetContent>
    </Sheet>
  )
}
