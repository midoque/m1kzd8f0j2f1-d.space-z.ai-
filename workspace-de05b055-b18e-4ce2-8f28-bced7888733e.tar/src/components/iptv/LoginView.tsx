'use client'

import { useState, FormEvent } from 'react'
import { motion } from 'framer-motion'
import {
  Tv,
  Link2,
  User,
  Lock,
  Eye,
  EyeOff,
  ArrowRight,
  ShieldCheck,
  Loader2,
} from 'lucide-react'
import { useIPTVStore } from '@/lib/iptv-store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { toast } from '@/hooks/use-toast'

export default function LoginView() {
  const setServer = useIPTVStore((s) => s.setServer)

  const [url, setUrl] = useState('http://')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [remember, setRemember] = useState(true)
  const [submitting, setSubmitting] = useState(false)

  const isValid =
    url.trim().length > 0 &&
    /^https?:\/\/.+/.test(url.trim()) &&
    username.trim().length > 0 &&
    password.length > 0

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!isValid) {
      toast({
        title: 'Missing fields',
        description: 'Please provide a valid URL, username, and password.',
        variant: 'destructive',
      })
      return
    }

    setSubmitting(true)
    // Simulate a brief connection handshake so the UX feels real.
    await new Promise((r) => setTimeout(r, 850))
    setSubmitting(false)

    setServer({
      url: url.trim(),
      username: username.trim(),
      password,
    })

    if (remember) {
      // Persisting is handled by zustand persist middleware; nothing else to do.
    }

    toast({
      title: 'Connected',
      description: `Welcome, ${username.trim()}! Your IPTV server is ready.`,
    })
  }

  function handleDemo() {
    setUrl('http://demo.iptv.example')
    setUsername('demo')
    setPassword('demo1234')
  }

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-background">
      {/* Ambient backdrop */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 -left-32 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute -bottom-40 -right-32 h-96 w-96 rounded-full bg-chart-5/10 blur-3xl" />
        <div className="absolute top-1/3 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-chart-1/10 blur-3xl" />
      </div>

      <div className="relative z-10 flex min-h-screen items-center justify-center p-4 sm:p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: 'easeOut' }}
          className="w-full max-w-md"
        >
          <div className="mb-8 flex flex-col items-center text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg">
              <Tv className="h-8 w-8" />
            </div>
            <h1 className="text-3xl font-semibold tracking-tight">
              StreamVerse IPTV
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Connect to your IPTV server and start watching.
            </p>
          </div>

          <Card className="border-border/60 shadow-xl">
            <CardHeader className="space-y-1.5">
              <CardTitle className="text-xl">Server connection</CardTitle>
              <CardDescription>
                Enter your provider details below to access live channels.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="server-url">Server URL</Label>
                  <div className="relative">
                    <Link2 className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="server-url"
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      placeholder="http://your-iptv-server.com:8080"
                      autoComplete="url"
                      className="pl-9"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="your_username"
                      autoComplete="username"
                      className="pl-9"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      autoComplete="current-password"
                      className="pl-9 pr-9"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((v) => !v)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground transition-colors hover:text-foreground"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="remember"
                      checked={remember}
                      onCheckedChange={(v) => setRemember(!!v)}
                    />
                    <Label
                      htmlFor="remember"
                      className="cursor-pointer text-sm font-normal text-muted-foreground"
                    >
                      Remember this server
                    </Label>
                  </div>
                  <button
                    type="button"
                    onClick={handleDemo}
                    className="text-xs font-medium text-primary transition-colors hover:text-primary/80"
                  >
                    Use demo
                  </button>
                </div>

                <Button
                  type="submit"
                  disabled={!isValid || submitting}
                  className="w-full"
                  size="lg"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Connecting...
                    </>
                  ) : (
                    <>
                      Connect
                      <ArrowRight className="h-4 w-4" />
                    </>
                  )}
                </Button>

                <p className="flex items-center justify-center gap-1.5 pt-1 text-center text-xs text-muted-foreground">
                  <ShieldCheck className="h-3.5 w-3.5" />
                  Credentials are stored locally on this device only.
                </p>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}
