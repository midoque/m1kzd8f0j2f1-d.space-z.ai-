'use client'

import {
  Sun,
  Moon,
  Volume2,
  LogOut,
  Tv,
  Server,
  User,
  ShieldCheck,
  Github,
  Info,
  Zap,
} from 'lucide-react'
import { useIPTVStore } from '@/lib/iptv-store'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Switch } from '@/components/ui/switch'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { toast } from '@/hooks/use-toast'

export default function SettingsView() {
  const theme = useIPTVStore((s) => s.theme)
  const setTheme = useIPTVStore((s) => s.setTheme)
  const autoplay = useIPTVStore((s) => s.autoplay)
  const setAutoplay = useIPTVStore((s) => s.setAutoplay)
  const preferredQuality = useIPTVStore((s) => s.preferredQuality)
  const setPreferredQuality = useIPTVStore((s) => s.setPreferredQuality)
  const server = useIPTVStore((s) => s.server)
  const logout = useIPTVStore((s) => s.logout)
  const channels = useIPTVStore((s) => s.channels)
  const pairedDevices = useIPTVStore((s) => s.pairedDevices)

  function handleThemeToggle(checked: boolean) {
    setTheme(checked ? 'dark' : 'light')
    // Apply theme to <html> for next-themes compatibility
    if (typeof document !== 'undefined') {
      document.documentElement.classList.toggle('dark', checked)
    }
  }

  return (
    <div className="space-y-6 p-4 sm:p-6 lg:p-8">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
          Settings
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Configure playback, appearance and connection.
        </p>
      </div>

      {/* Account */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <User className="h-4 w-4" />
            Account
          </CardTitle>
          <CardDescription>Your IPTV server connection details.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <Detail
              icon={<Server className="h-3.5 w-3.5" />}
              label="Server URL"
              value={server?.url ?? '—'}
            />
            <Detail
              icon={<User className="h-3.5 w-3.5" />}
              label="Username"
              value={server?.username ?? '—'}
            />
            <Detail
              icon={<ShieldCheck className="h-3.5 w-3.5" />}
              label="Password"
              value="••••••••"
            />
          </div>
          <Button
            variant="outline"
            onClick={() => {
              logout()
              toast({ title: 'Signed out', description: 'Your server credentials were cleared.' })
            }}
          >
            <LogOut className="h-4 w-4" />
            Sign out & clear server
          </Button>
        </CardContent>
      </Card>

      {/* Appearance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            {theme === 'dark' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
            Appearance
          </CardTitle>
          <CardDescription>Customize how StreamVerse looks.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Row
            title="Dark mode"
            description="Use dark surfaces for low-light viewing."
          >
            <Switch checked={theme === 'dark'} onCheckedChange={handleThemeToggle} />
          </Row>
        </CardContent>
      </Card>

      {/* Playback */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Volume2 className="h-4 w-4" />
            Playback
          </CardTitle>
          <CardDescription>Tune default streaming behaviour.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Row
            title="Autoplay"
            description="Start playback automatically when a channel is selected."
          >
            <Switch checked={autoplay} onCheckedChange={setAutoplay} />
          </Row>
          <Row
            title="Preferred quality"
            description="Default stream quality used when available."
          >
            <Select
              value={preferredQuality}
              onValueChange={(v) =>
                setPreferredQuality(v as typeof preferredQuality)
              }
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="auto">Auto</SelectItem>
                <SelectItem value="1080p">1080p</SelectItem>
                <SelectItem value="720p">720p</SelectItem>
                <SelectItem value="480p">480p</SelectItem>
                <SelectItem value="360p">360p</SelectItem>
              </SelectContent>
            </Select>
          </Row>
        </CardContent>
      </Card>

      {/* About */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Info className="h-4 w-4" />
            About
          </CardTitle>
          <CardDescription>App version and library stats.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat icon={<Tv className="h-4 w-4" />} label="Channels" value={channels.length} />
            <Stat icon={<Zap className="h-4 w-4" />} label="Paired devices" value={pairedDevices.length} />
            <Stat icon={<ShieldCheck className="h-4 w-4" />} label="Version" value="1.0.0" />
            <Stat icon={<Github className="h-4 w-4" />} label="License" value="MIT" />
          </div>
          <p className="pt-2 text-xs text-muted-foreground">
            StreamVerse IPTV is a demo client. Stream URLs are played directly in your browser via HLS.js.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

function Row({
  title,
  description,
  children,
}: {
  title: string
  description: string
  children: React.ReactNode
}) {
  return (
    <div className="flex items-center justify-between gap-4 py-2">
      <div>
        <p className="text-sm font-medium">{title}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
      {children}
    </div>
  )
}

function Detail({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode
  label: string
  value: string
}) {
  return (
    <div className="rounded-lg border p-3">
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
        {icon}
        {label}
      </div>
      <p className="mt-1 truncate text-sm font-medium" title={value}>{value}</p>
    </div>
  )
}

function Stat({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode
  label: string
  value: string | number
}) {
  return (
    <div className="rounded-lg border p-3 text-center">
      <div className="mx-auto mb-1 flex h-7 w-7 items-center justify-center rounded-md bg-primary/10 text-primary">
        {icon}
      </div>
      <p className="text-sm font-semibold">{value}</p>
      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
        {label}
      </p>
    </div>
  )
}
